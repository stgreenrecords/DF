# {Lane Name} Implementation Subdashboard

This is the lane-specific queue for `{lane-role}` work. The main board remains the overall task source of truth.

| Priority | Task ID | Parent task | Title | State | Owner role | Affected scope | Blocked? | Last updated | Next action |
|---|---|---|---|---|---|---|---|---|---|
| P1 | TASK-001-{lane-suffix} | TASK-001 | Example lane task | READY_FOR_DEV | {lane-role} | {affected-scope} | No | YYYY-MM-DD HH:mm local | Start work |

## Lane rules

- Only tasks owned by `{lane-role}` belong here.
- Each task here must also appear on `df/runtime/board.md` or be linked from a parent task there.
- Update this file only while acting as the owning role, SA during routing, QA during failure routing, or PO during rejection routing.
- Do not edit another lane's subdashboard.
- Lane notes belong under `df/artifacts/{task-id}/{lane-folder}/`.
- For `frontend-dev`, `Affected scope` should name the target client/app path.
- For `designer`, use owner `designer`, design states, and artifact folder `df/artifacts/{task-id}/design/`.

