# Data Engineer Runtime Subdashboard

This is the live queue for `data-engineer` tasks. The main board remains the overall task source of truth.

| Priority | Task ID | Parent task | Title | State | Owner role | Affected scope | Blocked? | Last updated | Next action |
|---|---|---|---|---|---|---|---|---|---|
| - | - | - | No active data tasks | NO_TASKS | data-engineer | - | No | YYYY-MM-DD HH:mm local | Await the next data task |

## Lane notes

- New data tasks must be added here before `data-engineer` starts work.
- Data notes belong under `df/artifacts/{task-id}/data/`.
- Source-backed data and synthetic/private-data separation rules should be documented per project when relevant.

