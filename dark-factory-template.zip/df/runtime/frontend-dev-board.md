# Frontend Developer Runtime Subdashboard

This is the live queue for `frontend-dev` tasks. The main board remains the overall task source of truth.

| Priority | Task ID | Parent task | Title | State | Owner role | Affected scope | Blocked? | Last updated | Next action |
|---|---|---|---|---|---|---|---|---|---|
| - | - | - | No active frontend tasks | NO_TASKS | frontend-dev | - | No | YYYY-MM-DD HH:mm local | Await the next frontend task |

## Lane notes

- New frontend tasks must be added here before `frontend-dev` starts work.
- UI-facing work requires a design package before implementation.
- Frontend notes belong under `df/artifacts/{task-id}/frontend/`.

