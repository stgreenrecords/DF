# Backend Developer Runtime Subdashboard

This is the live queue for `backend-dev` tasks. The main board remains the overall task source of truth.

| Priority | Task ID | Parent task | Title | State | Owner role | Affected scope | Blocked? | Last updated | Next action |
|---|---|---|---|---|---|---|---|---|---|
| - | - | - | No active backend tasks | NO_TASKS | backend-dev | - | No | YYYY-MM-DD HH:mm local | Await the next backend task |

## Lane notes

- New backend tasks must be added here before `backend-dev` starts work.
- Backend notes belong under `df/artifacts/{task-id}/backend/`.

