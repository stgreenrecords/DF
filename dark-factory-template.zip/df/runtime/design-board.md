# Designer Runtime Subdashboard

This is the live queue for `designer` tasks. The main board remains the overall task source of truth.

| Priority | Task ID | Parent task | Title | State | Owner role | Affected scope | Blocked? | Last updated | Next action |
|---|---|---|---|---|---|---|---|---|---|
| - | - | - | No active design tasks | NO_TASKS | designer | - | No | YYYY-MM-DD HH:mm local | Await the next design task |

## Lane notes

- New design tasks must be added here before `designer` starts work.
- Design docs belong under `df/artifacts/{task-id}/design/`.
- Root design assets belong under `design/{page-slug}/`.

