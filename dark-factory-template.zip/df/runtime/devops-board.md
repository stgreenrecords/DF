# DevOps Runtime Subdashboard

This is the live queue for `devops` tasks. The main board remains the overall task source of truth.

| Priority | Task ID | Parent task | Title | State | Owner role | Affected scope | Blocked? | Last updated | Next action |
|---|---|---|---|---|---|---|---|---|---|
| - | - | - | No active DevOps tasks | NO_TASKS | devops | - | No | YYYY-MM-DD HH:mm local | Await the next DevOps task |

## Lane notes

- New DevOps tasks must be added here before `devops` starts work.
- DevOps notes belong under `df/artifacts/{task-id}/devops/`.

