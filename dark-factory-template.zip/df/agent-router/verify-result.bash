#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

VALID_ROLES=(sa designer backend-dev frontend-dev devops data-engineer qa po)
VALID_ADAPTERS=(manual)
EXECUTABLE_FILES=(
  "$SCRIPT_DIR/df-role.bash"
  "$SCRIPT_DIR/render-prompt.bash"
  "$SCRIPT_DIR/verify-result.bash"
  "$SCRIPT_DIR/adapters/manual.bash"
)

usage() {
  cat <<'EOF'
Usage:
  ./df/agent-router/verify-result.bash <run-dir> <task-id> <role> <adapter> <adapter-exit-code>
EOF
}

contains_value() {
  local needle="$1"
  shift
  local value
  for value in "$@"; do
    if [ "$value" = "$needle" ]; then
      return 0
    fi
  done
  return 1
}

json_escape() {
  local value="${1-}"
  value=${value//\\/\\\\}
  value=${value//\"/\\\"}
  value=${value//$'\n'/\\n}
  value=${value//$'\r'/\\r}
  value=${value//$'\t'/\\t}
  printf '%s' "$value"
}

find_json_validator() {
  if command -v python3 >/dev/null 2>&1; then
    printf 'python3'
  elif command -v python >/dev/null 2>&1; then
    printf 'python'
  elif command -v node >/dev/null 2>&1; then
    printf 'node'
  elif command -v powershell.exe >/dev/null 2>&1; then
    printf 'powershell.exe'
  else
    return 1
  fi
}

validate_json_file() {
  local file_path="$1"
  local validator
  validator="$(find_json_validator || true)"

  if [ -z "$validator" ]; then
    return 1
  fi

  case "$validator" in
    python3|python)
      "$validator" - "$file_path" <<'PY'
import json
import pathlib
import sys
path = pathlib.Path(sys.argv[1])
with path.open('r', encoding='utf-8') as handle:
    json.load(handle)
PY
      ;;
    node)
      "$validator" -e "JSON.parse(require('fs').readFileSync(process.argv[1], 'utf8'));" "$file_path"
      ;;
    powershell.exe)
      "$validator" -NoLogo -NoProfile -Command "Get-Content -LiteralPath '$file_path' -Raw | ConvertFrom-Json | Out-Null"
      ;;
  esac
}

append_issue() {
  ISSUES+=("$1")
}

append_warning() {
  WARNINGS+=("$1")
}

check_exists() {
  local file_path="$1"
  local label="$2"
  if [ ! -e "$file_path" ]; then
    append_issue "$label is missing: $file_path"
    return 1
  fi
  return 0
}

check_non_empty() {
  local file_path="$1"
  local label="$2"
  if [ ! -s "$file_path" ]; then
    append_issue "$label is empty: $file_path"
    return 1
  fi
  return 0
}

if [ "$#" -ne 5 ]; then
  usage >&2
  exit 1
fi

RUN_DIR="$1"
TASK_ID="$2"
ROLE="$3"
ADAPTER="$4"
ADAPTER_EXIT_CODE="$5"

PROMPT_FILE="$RUN_DIR/prompt.md"
ADAPTER_JSON="$RUN_DIR/adapter.json"
TRANSCRIPT_FILE="$RUN_DIR/transcript.md"
RESULT_JSON="$RUN_DIR/result.json"
VERIFICATION_FILE="$RUN_DIR/verification.md"
GIT_BEFORE_FILE="$RUN_DIR/git-before.txt"
GIT_AFTER_FILE="$RUN_DIR/git-after.txt"
DIFF_FILE="$RUN_DIR/diff.patch"

ISSUES=()
WARNINGS=()
STATUS="READY_FOR_QA"
VERIFICATION_PASSED=true
EXIT_CODE=0

check_exists "$RUN_DIR" "Run directory" || true
check_exists "$PROMPT_FILE" "Prompt file" || true
check_non_empty "$PROMPT_FILE" "Prompt file" || true
check_exists "$ADAPTER_JSON" "Adapter metadata" || true
check_exists "$TRANSCRIPT_FILE" "Transcript" || true
check_exists "$GIT_BEFORE_FILE" "Git before snapshot" || true
check_exists "$GIT_AFTER_FILE" "Git after snapshot" || true
check_exists "$DIFF_FILE" "Diff patch" || true

if [ -f "$ADAPTER_JSON" ] && ! validate_json_file "$ADAPTER_JSON" >/dev/null 2>&1; then
  append_issue "Adapter metadata is not valid JSON: $ADAPTER_JSON"
fi

if ! contains_value "$ROLE" "${VALID_ROLES[@]}"; then
  append_issue "Role is invalid: $ROLE"
fi

if ! contains_value "$ADAPTER" "${VALID_ADAPTERS[@]}"; then
  append_issue "Adapter is invalid: $ADAPTER"
fi

for file_path in "${EXECUTABLE_FILES[@]}"; do
  if [ ! -f "$file_path" ]; then
    append_issue "Required executable file is missing: $file_path"
  fi
done

if [ -f "$TRANSCRIPT_FILE" ]; then
  if grep -q 'AGENT_ROUTER_MANUAL_PENDING' "$TRANSCRIPT_FILE"; then
    STATUS="MANUAL_ACTION_REQUIRED"
    append_warning "Manual adapter still requires an operator-supplied transcript."
  elif ! grep -q '[^[:space:]]' "$TRANSCRIPT_FILE"; then
    append_issue "Transcript exists but is empty."
  fi
fi

if [ "$STATUS" = "READY_FOR_QA" ] && [ "$ADAPTER_EXIT_CODE" -ne 0 ]; then
  append_warning "Adapter exit code was non-zero: $ADAPTER_EXIT_CODE"
fi

if [ "${#ISSUES[@]}" -gt 0 ]; then
  STATUS="FAILED_VERIFICATION"
fi

case "$STATUS" in
  READY_FOR_QA)
    VERIFICATION_PASSED=true
    EXIT_CODE=0
    ;;
  MANUAL_ACTION_REQUIRED|FAILED_VERIFICATION|BLOCKED)
    VERIFICATION_PASSED=false
    EXIT_CODE=1
    ;;
  *)
    STATUS="FAILED_VERIFICATION"
    VERIFICATION_PASSED=false
    append_issue "Computed status was invalid."
    EXIT_CODE=1
    ;;
esac

cat > "$RESULT_JSON" <<EOF
{
  "taskId": "$(json_escape "$TASK_ID")",
  "role": "$(json_escape "$ROLE")",
  "adapter": "$(json_escape "$ADAPTER")",
  "status": "$(json_escape "$STATUS")",
  "verificationPassed": $VERIFICATION_PASSED,
  "runDirectory": "$(json_escape "$RUN_DIR")",
  "createdAt": "$(json_escape "$(date +%Y%m%d-%H%M%S 2>/dev/null || printf '00000000-000000')")",
  "adapterExitCode": ${ADAPTER_EXIT_CODE},
  "notes": {
    "issueCount": ${#ISSUES[@]},
    "warningCount": ${#WARNINGS[@]}
  }
}
EOF

if ! validate_json_file "$RESULT_JSON" >/dev/null 2>&1; then
  append_issue "Result JSON could not be validated after creation."
  STATUS="FAILED_VERIFICATION"
  VERIFICATION_PASSED=false
  EXIT_CODE=1
fi

{
  printf '# Verification - %s\n\n' "$TASK_ID"
  printf -- '- Role: `%s`\n' "$ROLE"
  printf -- '- Adapter: `%s`\n' "$ADAPTER"
  printf -- '- Status: `%s`\n' "$STATUS"
  printf -- '- Verification passed: `%s`\n' "$VERIFICATION_PASSED"
  printf -- '- Adapter exit code: `%s`\n\n' "$ADAPTER_EXIT_CODE"

  printf '## Required file checks\n\n'
  printf '| Item | Expected | Result |\n'
  printf '|---|---|---|\n'
  for item in "$PROMPT_FILE" "$ADAPTER_JSON" "$TRANSCRIPT_FILE" "$RESULT_JSON" "$VERIFICATION_FILE" "$GIT_BEFORE_FILE" "$GIT_AFTER_FILE" "$DIFF_FILE"; do
    if [ -e "$item" ]; then
      printf '| `%s` | present | PASS |\n' "$item"
    else
      printf '| `%s` | present | FAIL |\n' "$item"
    fi
  done
  printf '\n'

  printf '## Issues\n\n'
  if [ "${#ISSUES[@]}" -eq 0 ]; then
    printf -- '- none\n'
  else
    local_issue=''
    for local_issue in "${ISSUES[@]}"; do
      printf -- '- %s\n' "$local_issue"
    done
  fi
  printf '\n'

  printf '## Warnings\n\n'
  if [ "${#WARNINGS[@]}" -eq 0 ]; then
    printf -- '- none\n'
  else
    local_warning=''
    for local_warning in "${WARNINGS[@]}"; do
      printf -- '- %s\n' "$local_warning"
    done
  fi
  printf '\n'

  printf '## Verification summary\n\n'
  case "$STATUS" in
    READY_FOR_QA)
      printf 'All required files exist, metadata is valid, and the transcript is usable.\n'
      ;;
    MANUAL_ACTION_REQUIRED)
      printf 'The run folder is complete, but the manual adapter still requires the placeholder transcript to be replaced with a real routed-session response.\n'
      ;;
    *)
      printf 'Verification failed. Review the issues above and correct the run evidence before treating this session as successful.\n'
      ;;
  esac
} > "$VERIFICATION_FILE"

exit "$EXIT_CODE"
