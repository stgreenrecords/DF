#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"

VALID_ROLES=(sa designer backend-dev frontend-dev devops data-engineer qa po)
VALID_ADAPTERS=(manual)

usage() {
  cat <<'EOF'
Usage:
  ./df/agent-router/df-role.bash <task-id> <role> --adapter manual

Examples:
  ./df/agent-router/df-role.bash TASK-001 backend-dev --adapter manual
  ./df/agent-router/df-role.bash TASK-001 qa --adapter manual
EOF
}

contains_value() {
  local needle="$1"
  shift
  local value
  for value in "$@"; do
    if [ "$value" = "$needle" ]; then
      return 0
    fi
  done
  return 1
}

json_escape() {
  local value="${1-}"
  value=${value//\\/\\\\}
  value=${value//\"/\\\"}
  value=${value//$'\n'/\\n}
  value=${value//$'\r'/\\r}
  value=${value//$'\t'/\\t}
  printf '%s' "$value"
}

timestamp_now() {
  if command -v date >/dev/null 2>&1; then
    date +%Y%m%d-%H%M%S
  else
    printf '00000000-000000'
  fi
}

write_text_file() {
  local path="$1"
  local content="$2"
  printf '%s\n' "$content" > "$path"
}

capture_git_status() {
  local path="$1"
  local phase="$2"

  if git -C "$REPO_ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    if ! git -C "$REPO_ROOT" --no-pager status --short --branch > "$path" 2>&1; then
      write_text_file "$path" "Git status capture failed during ${phase}."
    fi
  else
    write_text_file "$path" "Git metadata is unavailable during ${phase}."
  fi
}

capture_git_diff() {
  local path="$1"

  if git -C "$REPO_ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    if ! git -C "$REPO_ROOT" --no-pager diff --binary --no-ext-diff > "$path" 2>&1; then
      write_text_file "$path" "Git diff capture failed."
    fi
  else
    write_text_file "$path" "Git metadata is unavailable; diff could not be collected."
  fi
}

write_adapter_metadata() {
  local path="$1"
  local task_id="$2"
  local role="$3"
  local adapter="$4"
  local run_dir="$5"
  local prompt_file="$6"
  local transcript_file="$7"
  local adapter_exit_code="$8"
  local adapter_status="$9"

  cat > "$path" <<EOF
{
  "taskId": "$(json_escape "$task_id")",
  "role": "$(json_escape "$role")",
  "adapter": "$(json_escape "$adapter")",
  "createdAt": "$(json_escape "$(timestamp_now)")",
  "runDirectory": "$(json_escape "$run_dir")",
  "promptFile": "$(json_escape "$prompt_file")",
  "transcriptFile": "$(json_escape "$transcript_file")",
  "adapterExitCode": ${adapter_exit_code},
  "adapterStatus": "$(json_escape "$adapter_status")"
}
EOF
}

TASK_ID="${1-}"
ROLE="${2-}"
shift $(( $# >= 2 ? 2 : $# )) || true
ADAPTER=""

while [ $# -gt 0 ]; do
  case "$1" in
    --adapter)
      shift || true
      ADAPTER="${1-}"
      ;;
    --adapter=*)
      ADAPTER="${1#*=}"
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      printf 'Unknown argument: %s\n\n' "$1" >&2
      usage >&2
      exit 1
      ;;
  esac
  shift || true
done

if [ -z "$TASK_ID" ] || [ -z "$ROLE" ] || [ -z "$ADAPTER" ]; then
  usage >&2
  printf '\nError: task id, role, and --adapter are required.\n' >&2
  exit 1
fi

if ! contains_value "$ROLE" "${VALID_ROLES[@]}"; then
  printf 'Error: invalid role "%s". Allowed roles: %s\n' "$ROLE" "${VALID_ROLES[*]}" >&2
  exit 1
fi

if ! contains_value "$ADAPTER" "${VALID_ADAPTERS[@]}"; then
  printf 'Error: invalid adapter "%s". Allowed adapters: %s\n' "$ADAPTER" "${VALID_ADAPTERS[*]}" >&2
  exit 1
fi

RUNS_ROOT="$REPO_ROOT/df/artifacts/$TASK_ID/agent-runs"
TIMESTAMP="$(timestamp_now)"
RUN_DIR="$RUNS_ROOT/$TIMESTAMP-$ROLE"
COUNTER=1
while [ -e "$RUN_DIR" ]; do
  RUN_DIR="$RUNS_ROOT/$TIMESTAMP-$ROLE-$COUNTER"
  COUNTER=$((COUNTER + 1))
done
mkdir -p "$RUN_DIR"

PROMPT_FILE="$RUN_DIR/prompt.md"
ADAPTER_JSON="$RUN_DIR/adapter.json"
TRANSCRIPT_FILE="$RUN_DIR/transcript.md"
RESULT_JSON="$RUN_DIR/result.json"
VERIFICATION_FILE="$RUN_DIR/verification.md"
GIT_BEFORE_FILE="$RUN_DIR/git-before.txt"
GIT_AFTER_FILE="$RUN_DIR/git-after.txt"
DIFF_FILE="$RUN_DIR/diff.patch"

write_text_file "$PROMPT_FILE" "Prompt rendering has not run yet."
write_text_file "$TRANSCRIPT_FILE" "Transcript has not been captured yet."
write_text_file "$VERIFICATION_FILE" "Verification has not run yet."
write_text_file "$GIT_BEFORE_FILE" "Git status has not been captured yet."
write_text_file "$GIT_AFTER_FILE" "Git status has not been captured yet."
: > "$DIFF_FILE"
: > "$RESULT_JSON"

capture_git_status "$GIT_BEFORE_FILE" "before adapter execution"

if ! "$SCRIPT_DIR/render-prompt.bash" "$TASK_ID" "$ROLE" "$RUN_DIR" > "$PROMPT_FILE"; then
  write_text_file "$PROMPT_FILE" "Prompt rendering failed for task $TASK_ID and role $ROLE."
fi

write_adapter_metadata "$ADAPTER_JSON" "$TASK_ID" "$ROLE" "$ADAPTER" "$RUN_DIR" "$PROMPT_FILE" "$TRANSCRIPT_FILE" 0 prepared

ADAPTER_SCRIPT="$SCRIPT_DIR/adapters/$ADAPTER.bash"
ADAPTER_EXIT_CODE=0

if [ -f "$ADAPTER_SCRIPT" ]; then
  set +e
  "$ADAPTER_SCRIPT" \
    --task-id "$TASK_ID" \
    --role "$ROLE" \
    --run-dir "$RUN_DIR" \
    --prompt-file "$PROMPT_FILE" \
    --transcript-file "$TRANSCRIPT_FILE" \
    --adapter-json "$ADAPTER_JSON"
  ADAPTER_EXIT_CODE=$?
  set -e
else
  ADAPTER_EXIT_CODE=127
  write_text_file "$TRANSCRIPT_FILE" "Selected adapter script was not found: $ADAPTER_SCRIPT"
fi

capture_git_status "$GIT_AFTER_FILE" "after adapter execution"
capture_git_diff "$DIFF_FILE"
write_adapter_metadata "$ADAPTER_JSON" "$TASK_ID" "$ROLE" "$ADAPTER" "$RUN_DIR" "$PROMPT_FILE" "$TRANSCRIPT_FILE" "$ADAPTER_EXIT_CODE" completed

set +e
"$SCRIPT_DIR/verify-result.bash" "$RUN_DIR" "$TASK_ID" "$ROLE" "$ADAPTER" "$ADAPTER_EXIT_CODE"
VERIFY_EXIT_CODE=$?
set -e

exit "$VERIFY_EXIT_CODE"
