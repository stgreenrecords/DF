#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  ./df/agent-router/adapters/manual.bash \
    --task-id <task-id> \
    --role <role> \
    --run-dir <run-dir> \
    --prompt-file <prompt.md> \
    --transcript-file <transcript.md> \
    --adapter-json <adapter.json>
EOF
}

TASK_ID=""
ROLE=""
RUN_DIR=""
PROMPT_FILE=""
TRANSCRIPT_FILE=""
ADAPTER_JSON=""

while [ $# -gt 0 ]; do
  case "$1" in
    --task-id)
      TASK_ID="${2-}"
      shift 2
      ;;
    --role)
      ROLE="${2-}"
      shift 2
      ;;
    --run-dir)
      RUN_DIR="${2-}"
      shift 2
      ;;
    --prompt-file)
      PROMPT_FILE="${2-}"
      shift 2
      ;;
    --transcript-file)
      TRANSCRIPT_FILE="${2-}"
      shift 2
      ;;
    --adapter-json)
      ADAPTER_JSON="${2-}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      printf 'Unknown argument: %s\n' "$1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

if [ -z "$TASK_ID" ] || [ -z "$ROLE" ] || [ -z "$RUN_DIR" ] || [ -z "$PROMPT_FILE" ] || [ -z "$TRANSCRIPT_FILE" ] || [ -z "$ADAPTER_JSON" ]; then
  usage >&2
  exit 1
fi

if [ -n "${DF_AGENT_ROUTER_MANUAL_RESPONSE_FILE:-}" ] && [ -f "${DF_AGENT_ROUTER_MANUAL_RESPONSE_FILE}" ]; then
  cp "${DF_AGENT_ROUTER_MANUAL_RESPONSE_FILE}" "$TRANSCRIPT_FILE"
  printf 'Manual adapter loaded transcript from %s\n' "$DF_AGENT_ROUTER_MANUAL_RESPONSE_FILE"
  exit 0
fi

if [ -n "${DF_AGENT_ROUTER_MANUAL_RESPONSE_TEXT:-}" ]; then
  printf '%s\n' "$DF_AGENT_ROUTER_MANUAL_RESPONSE_TEXT" > "$TRANSCRIPT_FILE"
  printf 'Manual adapter loaded transcript text from DF_AGENT_ROUTER_MANUAL_RESPONSE_TEXT.\n'
  exit 0
fi

cat > "$TRANSCRIPT_FILE" <<EOF
<!-- AGENT_ROUTER_MANUAL_PENDING -->
# Manual adapter transcript pending

- Task: $TASK_ID
- Role: $ROLE
- Prompt file: $PROMPT_FILE
- Run folder: $RUN_DIR
- Adapter metadata file: $ADAPTER_JSON

## Operator instructions

1. Open the prompt in $PROMPT_FILE
2. Run that prompt in your chosen agent environment.
3. Replace this placeholder with the resulting transcript or save the response into this file.
4. Re-run verification only after this placeholder content is replaced.
EOF

cat <<EOF
Manual adapter prepared.

Prompt path:
  $PROMPT_FILE

Transcript path:
  $TRANSCRIPT_FILE

Next step:
  Run the prompt in your chosen agent, then replace the placeholder transcript with the real response.
EOF

