#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"

usage() {
  cat <<'EOF'
Usage:
  ./df/agent-router/render-prompt.bash <task-id> <role> <run-dir>
EOF
}

if [ "$#" -ne 3 ]; then
  usage >&2
  exit 1
fi

TASK_ID="$1"
ROLE="$2"
RUN_DIR="$3"
TEMPLATE_FILE="$SCRIPT_DIR/prompts/$ROLE.md"
ARTIFACT_ROOT="$REPO_ROOT/df/artifacts/$TASK_ID"
BOARD_FILE="$REPO_ROOT/df/runtime/board.md"
ACTIVITY_FILE="$REPO_ROOT/df/runtime/activity-log.md"
DECISIONS_FILE="$REPO_ROOT/df/runtime/decisions.md"
RISKS_FILE="$REPO_ROOT/df/runtime/risks.md"

if [ ! -f "$TEMPLATE_FILE" ]; then
  printf '# Prompt rendering warning\n\nMissing role template: `%s`\n' "$TEMPLATE_FILE"
  exit 0
fi

rel_path() {
  local path="$1"
  printf '%s' "${path#$REPO_ROOT/}"
}

emit_runtime_section() {
  local title="$1"
  local file_path="$2"
  local mode="$3"

  printf '## %s\n\n' "$title"
  printf -- '- Path: `%s`\n\n' "$(rel_path "$file_path")"

  if [ ! -f "$file_path" ]; then
    printf -- '> WARNING: missing runtime file `%s`. Continue with the available evidence and record the gap explicitly.\n\n' "$(rel_path "$file_path")"
    return
  fi

  printf '```markdown\n'
  if [ "$mode" = "tail" ]; then
    tail -n 120 "$file_path"
  else
    cat "$file_path"
  fi
  printf '\n```\n\n'
}

cat <<EOF
# Dark Factory Agent Router Prompt

- Task id: $TASK_ID
- Role: $ROLE
- Task artifact root: $(rel_path "$ARTIFACT_ROOT")
- Agent-run evidence folder for this session: $(rel_path "$RUN_DIR")
- Runtime files reviewed:
  - df/runtime/board.md
  - df/runtime/activity-log.md
  - df/runtime/decisions.md
  - df/runtime/risks.md

## Role template

EOF

cat "$TEMPLATE_FILE"
printf '\n\n'

cat <<EOF
## Required output contract

You must produce work for exactly one Dark Factory role session.

Required outcomes:
- keep the work within the assigned role only;
- write or update evidence under df/artifacts/$TASK_ID/ before claiming success;
- write run evidence for this routed session under $(rel_path "$RUN_DIR");
- do not mark the task DONE;
- provide a clear handoff for the next role;
- if validation cannot be completed, record the blocker instead of guessing.

Minimum response content expected from the routed role:
- summary of actions performed;
- files changed or artifacts created;
- tests or checks run, with results;
- known risks, blockers, and assumptions;
- recommended next role and next action.

EOF

emit_runtime_section "Current board state" "$BOARD_FILE" full
emit_runtime_section "Recent activity log context" "$ACTIVITY_FILE" tail
emit_runtime_section "Current decisions" "$DECISIONS_FILE" full
emit_runtime_section "Current risks and blockers" "$RISKS_FILE" full

