#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
BOARD_FILE="${DF_AGENT_ROUTER_BOARD_FILE:-$REPO_ROOT/df/runtime/board.md}"
VALID_ADAPTERS=(manual)
VALID_ROLES=(sa designer backend-dev frontend-dev devops data-engineer qa po)
DEFAULT_ADAPTER="${DF_AGENT_ROUTER_FACTORY_ADAPTER:-manual}"

usage() {
  cat <<'EOF'
Usage:
  ./df/agent-router/start-factory.bash [--adapter manual] [--max-iterations <n>] [--task-id <task-id>] [--role <role>] [--dry-run]

Examples:
  ./df/agent-router/start-factory.bash
  ./df/agent-router/start-factory.bash --task-id TASK-001 --dry-run

Notes:
  - This orchestrator starts one routed role session at a time via ./df/agent-router/df-role.bash.
  - The board order in df/runtime/board.md remains the source of truth.
  - The manual adapter is a safe baseline and expects a supplied transcript before the run can pass verification.
EOF
}

trim() {
  local value="$1"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s' "$value"
}

contains_value() {
  local needle="$1"
  shift
  local value
  for value in "$@"; do
    if [ "$value" = "$needle" ]; then
      return 0
    fi
  done
  return 1
}

read_json_field() {
  local file_path="$1"
  local field_name="$2"
  local python_command=""

  if command -v python3 >/dev/null 2>&1; then
    python_command="python3"
  elif command -v python >/dev/null 2>&1; then
    python_command="python"
  else
    printf 'Error: python3 or python is required to parse %s\n' "$file_path" >&2
    return 1
  fi

  "$python_command" - "$file_path" "$field_name" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
field = sys.argv[2]
with path.open('r', encoding='utf-8') as handle:
    data = json.load(handle)
value = data.get(field, '')
if isinstance(value, bool):
    print('true' if value else 'false')
else:
    print(value)
PY
}

board_checksum() {
  if [ ! -f "$BOARD_FILE" ]; then
    printf 'missing-board'
    return 0
  fi
  cksum < "$BOARD_FILE" | awk '{print $1":"$2}'
}

latest_run_dir() {
  local task_id="$1"
  local role="$2"
  local runs_root="$REPO_ROOT/df/artifacts/$task_id/agent-runs"
  local matches=()

  if [ ! -d "$runs_root" ]; then
    return 1
  fi

  shopt -s nullglob
  matches=("$runs_root"/*-"$role" "$runs_root"/*-"$role"-*)
  shopt -u nullglob

  if [ "${#matches[@]}" -eq 0 ]; then
    return 1
  fi

  printf '%s\n' "${matches[@]}" | sort | tail -n 1
}

select_actionable_row() {
  local forced_task_id="$1"
  local line=""
  local trimmed_line=""
  local compact_line=""
  local priority=""
  local task_id=""
  local title=""
  local type=""
  local state=""
  local owner_role=""
  local blocked=""
  local next_action=""

  while IFS= read -r line; do
    trimmed_line="$(trim "$line")"
    compact_line="${trimmed_line//[[:space:]]/}"

    case "$compact_line" in
      ''|\|Priority\|*|\|---*)
        continue
        ;;
      \|*)
        ;;
      *)
        continue
        ;;
    esac

    IFS='|' read -r _ priority task_id title type state owner_role blocked _ next_action _ <<< "$trimmed_line"
    priority="$(trim "$priority")"
    task_id="$(trim "$task_id")"
    title="$(trim "$title")"
    type="$(trim "$type")"
    state="$(trim "$state")"
    owner_role="$(trim "$owner_role")"
    blocked="$(trim "$blocked")"
    next_action="$(trim "$next_action")"

    if [ -n "$forced_task_id" ] && [ "$task_id" != "$forced_task_id" ]; then
      continue
    fi

    case "$state" in
      DONE|BLOCKED|NO_TASKS|'')
        continue
        ;;
    esac

    printf '%s|%s|%s|%s|%s|%s|%s|%s\n' "$priority" "$task_id" "$title" "$type" "$state" "$owner_role" "$blocked" "$next_action"
    return 0
  done < "$BOARD_FILE"

  return 1
}

determine_role() {
  local state="$1"
  local owner_role="$2"

  case "$state" in
    OPEN|INTAKE|REFINEMENT_IN_PROGRESS)
      printf 'sa'
      ;;
    REFINEMENT_QUESTIONS)
      printf 'po'
      ;;
    REFINED|NEEDS_ARCHITECTURE|ARCHITECTURE_IN_PROGRESS|ARCHITECTURE_REVIEW)
      printf 'sa'
      ;;
    READY_FOR_DESIGN|DESIGN_IN_PROGRESS)
      printf 'designer'
      ;;
    READY_FOR_DEV|DEV_IN_PROGRESS|RETURNED_TO_DEV)
      if ! contains_value "$owner_role" backend-dev frontend-dev devops data-engineer; then
        printf 'ERROR: delivery state %s requires a delivery-lane owner, got "%s".\n' "$state" "$owner_role" >&2
        return 1
      fi
      printf '%s' "$owner_role"
      ;;
    READY_FOR_QA|QA_IN_PROGRESS|QA_FAILED)
      printf 'qa'
      ;;
    READY_FOR_PO|PO_REVIEW|PO_REJECTED)
      printf 'po'
      ;;
    *)
      printf 'ERROR: unsupported actionable state "%s".\n' "$state" >&2
      return 1
      ;;
  esac
}

ADAPTER="$DEFAULT_ADAPTER"
MAX_ITERATIONS=20
FORCED_TASK_ID=""
FORCED_ROLE=""
DRY_RUN=false

while [ $# -gt 0 ]; do
  case "$1" in
    --adapter)
      shift || true
      ADAPTER="${1-}"
      ;;
    --adapter=*)
      ADAPTER="${1#*=}"
      ;;
    --max-iterations)
      shift || true
      MAX_ITERATIONS="${1-}"
      ;;
    --max-iterations=*)
      MAX_ITERATIONS="${1#*=}"
      ;;
    --task-id)
      shift || true
      FORCED_TASK_ID="${1-}"
      ;;
    --task-id=*)
      FORCED_TASK_ID="${1#*=}"
      ;;
    --role)
      shift || true
      FORCED_ROLE="${1-}"
      ;;
    --role=*)
      FORCED_ROLE="${1#*=}"
      ;;
    --dry-run)
      DRY_RUN=true
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      printf 'Unknown argument: %s\n\n' "$1" >&2
      usage >&2
      exit 1
      ;;
  esac
  shift || true
done

if ! contains_value "$ADAPTER" "${VALID_ADAPTERS[@]}"; then
  printf 'Error: invalid adapter "%s". Allowed adapters: %s\n' "$ADAPTER" "${VALID_ADAPTERS[*]}" >&2
  exit 1
fi

if ! [[ "$MAX_ITERATIONS" =~ ^[0-9]+$ ]] || [ "$MAX_ITERATIONS" -lt 1 ]; then
  printf 'Error: --max-iterations must be a positive integer.\n' >&2
  exit 1
fi

if [ -n "$FORCED_ROLE" ] && ! contains_value "$FORCED_ROLE" "${VALID_ROLES[@]}"; then
  printf 'Error: invalid role "%s". Allowed roles: %s\n' "$FORCED_ROLE" "${VALID_ROLES[*]}" >&2
  exit 1
fi

if [ ! -f "$BOARD_FILE" ]; then
  printf 'Error: runtime board not found at %s\n' "$BOARD_FILE" >&2
  exit 1
fi

iteration=1
while [ "$iteration" -le "$MAX_ITERATIONS" ]; do
  selection="$(select_actionable_row "$FORCED_TASK_ID" || true)"
  if [ -z "$selection" ]; then
    printf 'No actionable task found on %s.\n' "$BOARD_FILE"
    exit 0
  fi

  IFS='|' read -r priority task_id title type state owner_role blocked next_action <<< "$selection"
  role="$(determine_role "$state" "$owner_role")"

  if [ -n "$FORCED_ROLE" ] && [ "$role" != "$FORCED_ROLE" ]; then
    printf 'Error: task %s is currently owned by role "%s", not requested role "%s".\n' "$task_id" "$role" "$FORCED_ROLE" >&2
    exit 1
  fi

  printf 'Factory iteration %s/%s -> task %s, state %s, role %s, adapter %s\n' "$iteration" "$MAX_ITERATIONS" "$task_id" "$state" "$role" "$ADAPTER"
  if [ -n "$next_action" ]; then
    printf 'Board next action: %s\n' "$next_action"
  fi

  if [ "$DRY_RUN" = true ]; then
    exit 0
  fi

  board_before="$(board_checksum)"
  latest_before="$(latest_run_dir "$task_id" "$role" || true)"

  set +e
  "$SCRIPT_DIR/df-role.bash" "$task_id" "$role" --adapter "$ADAPTER"
  router_exit_code=$?
  set -e

  latest_after="$(latest_run_dir "$task_id" "$role" || true)"
  if [ -z "$latest_after" ] || [ "$latest_after" = "$latest_before" ]; then
    printf 'Router run did not produce a new evidence folder for task %s role %s.\n' "$task_id" "$role" >&2
    exit 1
  fi

  result_file="$latest_after/result.json"
  if [ ! -f "$result_file" ]; then
    printf 'Router result file is missing: %s\n' "$result_file" >&2
    exit 1
  fi

  result_status="$(read_json_field "$result_file" status)"
  verification_passed="$(read_json_field "$result_file" verificationPassed)"
  printf 'Router result -> status=%s, verificationPassed=%s, runDir=%s\n' "$result_status" "$verification_passed" "$latest_after"

  if [ "$result_status" != 'READY_FOR_QA' ] || [ "$verification_passed" != 'true' ]; then
    printf 'Stopping factory loop because the routed session did not complete verification cleanly.\n' >&2
    exit "${router_exit_code:-1}"
  fi

  board_after="$(board_checksum)"
  if [ "$board_before" = "$board_after" ]; then
    printf 'Stopping factory loop because the runtime board did not change after the routed session. Update runtime state before continuing automatically.\n' >&2
    exit 2
  fi

  iteration=$((iteration + 1))
done

printf 'Stopped after reaching the configured max iteration count (%s).\n' "$MAX_ITERATIONS"
exit 0
